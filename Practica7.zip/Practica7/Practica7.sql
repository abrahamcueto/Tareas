CREATE VIEW Vista1 AS Select Nombre,ApellidoPaterno,ApellidoMaterno,Sueldo from trabajadores ; 
CREATE VIEW Vista2 AS Select Nombre,ApellidoPaterno,ApellidoMaterno,Sueldo from trabajadores2;
CREATE VIEW Vista3 AS Select ApellidoPaterno,ApellidoMaterno,Nombre,Sueldo from trabajadores3;
CREATE VIEW Vista4 AS Select Sueldo,ApellidoPaterno,ApellidoMaterno,Nombre from trabajadores4;
CREATE VIEW Vista5 AS Select Sueldo,ApellidoMaterno,ApellidoPaterno,Nombre from trabajadores5;
CREATE VIEW Vista6 AS Select Sueldo,Nombre,ApellidoMaterno,ApellidoPaterno from trabajadores6;
CREATE VIEW Vista7 AS Select Nombre,Sueldo,ApellidoPaterno,ApellidoMaterno from trabajadores7;
CREATE VIEW Vista8 AS Select Nombre,ApellidoPaterno,Sueldo,ApellidoMaterno from trabajadores8;
CREATE VIEW Vista9 AS Select ApellidoMaterno Nombre,ApellidoPaterno,Sueldo from trabajadores9;
CREATE VIEW Vista10 AS Select Sueldo,ApellidoMaterno Nombre,ApellidoPaterno from trabajadores10;

select t1.idTrabajadores, concat(t1.Nombre,' ',t2.ApellidoPaterno,' ', t3.ApellidoMaterno ) as Nombre, t1.Sueldo
 from trabajadores t1, trabajadores2 t2, trabajadores3 t3
 