-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: localhost    Database: practicas
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `vista3`
--

DROP TABLE IF EXISTS `vista3`;
/*!50001 DROP VIEW IF EXISTS `vista3`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vista3` AS SELECT 
 1 AS `ApellidoPaterno`,
 1 AS `ApellidoMaterno`,
 1 AS `Nombre`,
 1 AS `Sueldo`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista2`
--

DROP TABLE IF EXISTS `vista2`;
/*!50001 DROP VIEW IF EXISTS `vista2`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vista2` AS SELECT 
 1 AS `Nombre`,
 1 AS `ApellidoPaterno`,
 1 AS `ApellidoMaterno`,
 1 AS `Sueldo`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista1`
--

DROP TABLE IF EXISTS `vista1`;
/*!50001 DROP VIEW IF EXISTS `vista1`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vista1` AS SELECT 
 1 AS `Nombre`,
 1 AS `Sueldo`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista7`
--

DROP TABLE IF EXISTS `vista7`;
/*!50001 DROP VIEW IF EXISTS `vista7`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vista7` AS SELECT 
 1 AS `Nombre`,
 1 AS `Sueldo`,
 1 AS `ApellidoPaterno`,
 1 AS `ApellidoMaterno`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista6`
--

DROP TABLE IF EXISTS `vista6`;
/*!50001 DROP VIEW IF EXISTS `vista6`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vista6` AS SELECT 
 1 AS `Sueldo`,
 1 AS `Nombre`,
 1 AS `ApellidoMaterno`,
 1 AS `ApellidoPaterno`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista5`
--

DROP TABLE IF EXISTS `vista5`;
/*!50001 DROP VIEW IF EXISTS `vista5`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vista5` AS SELECT 
 1 AS `Sueldo`,
 1 AS `ApellidoMaterno`,
 1 AS `ApellidoPaterno`,
 1 AS `Nombre`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista8`
--

DROP TABLE IF EXISTS `vista8`;
/*!50001 DROP VIEW IF EXISTS `vista8`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vista8` AS SELECT 
 1 AS `Nombre`,
 1 AS `ApellidoPaterno`,
 1 AS `Sueldo`,
 1 AS `ApellidoMaterno`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista4`
--

DROP TABLE IF EXISTS `vista4`;
/*!50001 DROP VIEW IF EXISTS `vista4`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vista4` AS SELECT 
 1 AS `Sueldo`,
 1 AS `ApellidoPaterno`,
 1 AS `ApellidoMaterno`,
 1 AS `Nombre`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista10`
--

DROP TABLE IF EXISTS `vista10`;
/*!50001 DROP VIEW IF EXISTS `vista10`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vista10` AS SELECT 
 1 AS `Sueldo`,
 1 AS `Nombre`,
 1 AS `ApellidoPaterno`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista9`
--

DROP TABLE IF EXISTS `vista9`;
/*!50001 DROP VIEW IF EXISTS `vista9`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vista9` AS SELECT 
 1 AS `Nombre`,
 1 AS `ApellidoPaterno`,
 1 AS `Sueldo`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vista3`
--

/*!50001 DROP VIEW IF EXISTS `vista3`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista3` AS select `trabajadores3`.`ApellidoPaterno` AS `ApellidoPaterno`,`trabajadores3`.`ApellidoMaterno` AS `ApellidoMaterno`,`trabajadores3`.`Nombre` AS `Nombre`,`trabajadores3`.`Sueldo` AS `Sueldo` from `trabajadores3` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista2`
--

/*!50001 DROP VIEW IF EXISTS `vista2`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista2` AS select `trabajadores2`.`Nombre` AS `Nombre`,`trabajadores2`.`ApellidoPaterno` AS `ApellidoPaterno`,`trabajadores2`.`ApellidoMaterno` AS `ApellidoMaterno`,`trabajadores2`.`Sueldo` AS `Sueldo` from `trabajadores2` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista1`
--

/*!50001 DROP VIEW IF EXISTS `vista1`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista1` AS select `trabajadores`.`Nombre` AS `Nombre`,`trabajadores`.`Sueldo` AS `Sueldo` from `trabajadores` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista7`
--

/*!50001 DROP VIEW IF EXISTS `vista7`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista7` AS select `trabajadores7`.`Nombre` AS `Nombre`,`trabajadores7`.`Sueldo` AS `Sueldo`,`trabajadores7`.`ApellidoPaterno` AS `ApellidoPaterno`,`trabajadores7`.`ApellidoMaterno` AS `ApellidoMaterno` from `trabajadores7` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista6`
--

/*!50001 DROP VIEW IF EXISTS `vista6`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista6` AS select `trabajadores6`.`Sueldo` AS `Sueldo`,`trabajadores6`.`Nombre` AS `Nombre`,`trabajadores6`.`ApellidoMaterno` AS `ApellidoMaterno`,`trabajadores6`.`ApellidoPaterno` AS `ApellidoPaterno` from `trabajadores6` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista5`
--

/*!50001 DROP VIEW IF EXISTS `vista5`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista5` AS select `trabajadores5`.`Sueldo` AS `Sueldo`,`trabajadores5`.`ApellidoMaterno` AS `ApellidoMaterno`,`trabajadores5`.`ApellidoPaterno` AS `ApellidoPaterno`,`trabajadores5`.`Nombre` AS `Nombre` from `trabajadores5` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista8`
--

/*!50001 DROP VIEW IF EXISTS `vista8`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista8` AS select `trabajadores8`.`Nombre` AS `Nombre`,`trabajadores8`.`ApellidoPaterno` AS `ApellidoPaterno`,`trabajadores8`.`Sueldo` AS `Sueldo`,`trabajadores8`.`ApellidoMaterno` AS `ApellidoMaterno` from `trabajadores8` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista4`
--

/*!50001 DROP VIEW IF EXISTS `vista4`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista4` AS select `trabajadores4`.`Sueldo` AS `Sueldo`,`trabajadores4`.`ApellidoPaterno` AS `ApellidoPaterno`,`trabajadores4`.`ApellidoMaterno` AS `ApellidoMaterno`,`trabajadores4`.`Nombre` AS `Nombre` from `trabajadores4` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista10`
--

/*!50001 DROP VIEW IF EXISTS `vista10`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista10` AS select `trabajadores10`.`Sueldo` AS `Sueldo`,`trabajadores10`.`ApellidoMaterno` AS `Nombre`,`trabajadores10`.`ApellidoPaterno` AS `ApellidoPaterno` from `trabajadores10` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista9`
--

/*!50001 DROP VIEW IF EXISTS `vista9`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista9` AS select `trabajadores9`.`ApellidoMaterno` AS `Nombre`,`trabajadores9`.`ApellidoPaterno` AS `ApellidoPaterno`,`trabajadores9`.`Sueldo` AS `Sueldo` from `trabajadores9` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping events for database 'practicas'
--

--
-- Dumping routines for database 'practicas'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-13  1:26:14
